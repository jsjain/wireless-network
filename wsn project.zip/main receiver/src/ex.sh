make clean
make telosb
sudo chmod 666 chmod /dev/ttyUSB0
make telosb install
